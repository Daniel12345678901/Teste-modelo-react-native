interface Repository {
    id: number;
    name: string;
    fullName: string;
    owner: string;
    description: string;
    language: string;
    stars: number;
    forks: number;
    url: string;
  }
  
 export const fakeRepos: Repository[] = [
    {
      id: 1,
      name: "project-one",
      fullName: "user/project-one",
      owner: "user",
      description: "Descrição do Project One",
      language: "TypeScript",
      stars: 120,
      forks: 50,
      url: "https://github.com/user/project-one"
    },
    {
      id: 2,
      name: "awesome-project",
      fullName: "dev/awesome-project",
      owner: "dev",
      description: "Projeto incrível para aprender GitHub",
      language: "JavaScript",
      stars: 200,
      forks: 75,
      url: "https://github.com/dev/awesome-project"
    },
    {
      id: 3,
      name: "cool-tool",
      fullName: "coder/cool-tool",
      owner: "coder",
      description: "Uma ferramenta legal para desenvolvedores",
      language: "Python",
      stars: 350,
      forks: 120,
      url: "https://github.com/coder/cool-tool"
    },
    {
      id: 4,
      name: "demo-app",
      fullName: "company/demo-app",
      owner: "company",
      description: "Aplicativo de demonstração para clientes",
      language: "Ruby",
      stars: 50,
      forks: 20,
      url: "https://github.com/company/demo-app"
    }
  ];
  
  console.log(fakeRepos);
  