import React from "react";
import { useEffect, useState } from "react"
import { FlatList, ScrollView, Text, View } from "react-native"
import { fakeRepos } from "../../repos";
import { Link } from 'expo-router';

type User ={
    name: string;
    id: number;
    login: string;
    avatar_url: string;
}


export default function Home(){

    useEffect(() => {
        getUserData();
        getReposData();
    }, [])

    const [user, setUser] = useState({} as User )
    const [repos, setRepos] = useState(fakeRepos)

    async function getReposData() {
        console.log('dentro do getReposData')
        await fetch ('https://api.github.com/users/stemmlerjs/repos', {
            method: 'GET'
        })
        .then(async (response) => await response.json())
        .then(data => {
            setRepos(data)
        })
    }

    async function getUserData(){
        console.log('dentro do getUserData')
        
        
        await fetch('https://api.github.com/users/stemmlerjs', {
            method: 'GET'
        })
            .then(async (response) => await response.json())
            .then(getUser =>{
                setUser(getUser) 
            } )


    }

    return (
        <>
        <ScrollView>
       
        <Text>ola, {user.name} </Text> 
        <Text>ola, {user.id} </Text> 
        <Text>ola, {user.avatar_url} </Text> 
        
        </ScrollView>
        <FlatList 
        data={fakeRepos}

                 renderItem={({item})=>
        (
            <View>  
                <Link
                    href={{
                        pathname: '/repos/[id]',
                        params: { 
                            id: item.id
                        }
                        
                      
                    }}>
                    <Text>{item.name}</Text>
                </Link>
            </View>
        )     
        
        } />
        </>     
    )
}