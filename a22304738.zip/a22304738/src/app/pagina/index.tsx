import { router } from "expo-router";
import { Pressable, Text } from "react-native";

export default function Pagina() {
    return (
        <Pressable
            onPress={() => {
                router.back()
            }}
        >
            <Text>Voltar</Text>
        </Pressable>
    )
}