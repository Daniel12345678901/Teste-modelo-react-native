import { useLocalSearchParams } from "expo-router";
import React from "react"
import { Text } from "react-native"
import { Link } from 'expo-router';

export default function Slug() {

    const local = useLocalSearchParams();

    return(
        <>
            <Text> Bom dia! Repo: {local.id} </Text>
            
            <Link href="../pagina">
                Ir para os Detalhes
            </Link>

          
        </>
    )

}